package com.dev.eventdicoding.ui.favorite

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dev.eventdicoding.viewmodel.FavoriteViewModel
import com.example.eventdicoding.databinding.FragmentFavoriteBinding
import com.example.eventdicoding.ui.EventAdapter
import com.dev.eventdicoding.database.EventFavoriteEntity
import com.example.eventdicoding.data.response.ListEventsItem

class FavoriteFragment : Fragment() {

    private var _binding: FragmentFavoriteBinding? = null
    private val binding get() = _binding!!
    private lateinit var favoriteViewModel: FavoriteViewModel
    private lateinit var adapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        favoriteViewModel = ViewModelProvider(this)[FavoriteViewModel::class.java]

        // Initialize the adapter with a click listener
        adapter = EventAdapter { event ->
            // Handle event click, for example, navigate to the detail screen
        }

        // Setup RecyclerView
        binding.recyclerViewFavorite.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewFavorite.adapter = adapter

        // Observe data from ViewModel
        favoriteViewModel.allFavorites.observe(viewLifecycleOwner) { favoriteEntities ->
            if (favoriteEntities.isEmpty()) {
                binding.tvNoData.visibility = View.VISIBLE
            } else {
                binding.tvNoData.visibility = View.GONE
            }

            // Convert List<EventFavoriteEntity> to List<ListEventsItem>
            val eventsList = favoriteEntities.map { it.toListEventsItem() }
            adapter.submitList(eventsList)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Extension function to convert EventFavoriteEntity to ListEventsItem
    private fun EventFavoriteEntity.toListEventsItem(): ListEventsItem {
        return ListEventsItem(
            id = this.id,
            name = this.name,
            description = this.description,
            beginTime = this.date.toString(), // Convert Long to String if needed
            mediaCover = this.imageUrl,
            ownerName = "",  // Fill this field based on your data needs
            cityName = "",   // Same here
            quota = 0,       // Set appropriately based on your logic
            registrants = 0, // Same here
            isFavorite = this.isFavorite
        )
    }
}
