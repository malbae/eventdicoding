package com.example.eventdicoding.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.eventdicoding.data.response.ListEventsItem
import com.example.eventdicoding.databinding.ItemEventGridBinding
import com.example.eventdicoding.databinding.ItemEventVerticalBinding

class EventAdapter(
    private val layoutType: LayoutType = LayoutType.Vertical, // Enum untuk menentukan tipe layout
    private val onItemClick: (ListEventsItem) -> Unit // Callback untuk klik item
) : ListAdapter<ListEventsItem, RecyclerView.ViewHolder>(DIFF_CALLBACK) {

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListEventsItem>() {
            override fun areItemsTheSame(oldItem: ListEventsItem, newItem: ListEventsItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: ListEventsItem, newItem: ListEventsItem): Boolean {
                return oldItem == newItem
            }
        }
    }

    // ViewHolder untuk tampilan Horizontal
    inner class HorizontalViewHolder(private val binding: ItemEventVerticalBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.tvEventName.text = event.name
            Glide.with(binding.ivEventImage.context).load(event.imageLogo).into(binding.ivEventImage)
            binding.root.setOnClickListener { onItemClick(event) }
        }
    }

    // ViewHolder untuk tampilan Grid
    inner class GridViewHolder(private val binding: ItemEventGridBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.tvEventName.text = event.name
            Glide.with(binding.ivEventImage.context).load(event.imageLogo).into(binding.ivEventImage)
            binding.root.setOnClickListener { onItemClick(event) }
        }
    }

    // ViewHolder untuk tampilan Vertikal (Default)
    inner class VerticalViewHolder(private val binding: ItemEventVerticalBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.tvEventName.text = event.name
            binding.tvEventTime.text = event.beginTime
            Glide.with(binding.ivEventImage.context).load(event.imageLogo).into(binding.ivEventImage)
            binding.root.setOnClickListener { onItemClick(event) }
        }
    }

    // Enum untuk menentukan jenis layout yang digunakan
    enum class LayoutType {
        Vertical, Horizontal, Grid
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        return when (layoutType) {
            LayoutType.Horizontal -> HorizontalViewHolder(
                ItemEventVerticalBinding.inflate(inflater, parent, false)
            )
            LayoutType.Grid -> GridViewHolder(
                ItemEventGridBinding.inflate(inflater, parent, false)
            )
            LayoutType.Vertical -> VerticalViewHolder(
                ItemEventVerticalBinding.inflate(inflater, parent, false)
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val event = getItem(position)
        when (holder) {
            is HorizontalViewHolder -> holder.bind(event)
            is GridViewHolder -> holder.bind(event)
            is VerticalViewHolder -> holder.bind(event)
        }
    }
}
