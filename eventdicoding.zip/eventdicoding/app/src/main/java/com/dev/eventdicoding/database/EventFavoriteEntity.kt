package com.dev.eventdicoding.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "event_favorites")
data class EventFavoriteEntity(
    @PrimaryKey val id: Int,
    val name: String,
    val description: String,
    val date: String,
    val imageUrl: String,
    val isFavorite: Boolean
)
