package com.example.eventdicoding.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.eventdicoding.databinding.FragmentHomeBinding
import com.example.eventdicoding.ui.EventAdapter


class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var homeViewModel: HomeViewModel
    private lateinit var upcomingAdapter: EventAdapter
    private lateinit var finishedAdapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inisialisasi ViewModel di onCreateView
        homeViewModel = ViewModelProvider(this)[HomeViewModel::class.java]

        // Inisialisasi view binding
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup Adapter dan RecyclerView
        setupRecyclerView()

        // Observasi Data ViewModel
        homeViewModel.upcomingEvents.observe(viewLifecycleOwner) { events ->
            upcomingAdapter.submitList(events)
        }

        homeViewModel.finishedEvents.observe(viewLifecycleOwner) { events ->
            finishedAdapter.submitList(events)
        }

        // Observasi Error Handling
        homeViewModel.errorMessage.observe(viewLifecycleOwner) { message ->
            // Tampilkan pesan error di UI jika ada
            binding.tvErrorMessage.visibility = if (message.isNotEmpty()) View.VISIBLE else View.GONE
            binding.tvErrorMessage.text = message
        }

        // Observasi Status Loading
        homeViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    private fun setupRecyclerView() {
        // Inisialisasi Adapter untuk Upcoming Events (Horizontal)
        upcomingAdapter = EventAdapter { event ->
            // Implementasi navigasi atau aksi ketika item Upcoming Event diklik
        }

        binding.rvUpcomingEvents.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = upcomingAdapter
        }

        // Inisialisasi Adapter untuk Finished Events (Vertical)
        finishedAdapter = EventAdapter { event ->
            // Implementasi navigasi atau aksi ketika item Finished Event diklik
        }

        binding.rvFinishedEvents.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = finishedAdapter
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
