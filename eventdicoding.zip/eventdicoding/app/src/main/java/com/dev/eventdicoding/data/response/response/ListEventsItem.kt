package com.example.eventdicoding.data.response

import android.os.Parcel
import android.os.Parcelable
import com.example.eventdicoding.model.Event
import com.google.gson.annotations.SerializedName
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

data class ListEventsItem(
    @field:SerializedName("summary") val summary: String = "",
    @field:SerializedName("mediaCover") val mediaCover: String = "",
    @field:SerializedName("registrants") val registrants: Int = 0,
    @field:SerializedName("imageLogo") val imageLogo: String = "",
    @field:SerializedName("link") val link: String = "",
    @field:SerializedName("description") val description: String = "",
    @field:SerializedName("ownerName") val ownerName: String = "",
    @field:SerializedName("cityName") val cityName: String = "",
    @field:SerializedName("quota") val quota: Int = 0,
    @field:SerializedName("name") val name: String = "",
    @field:SerializedName("id") val id: Int = 0,  // Tetap sebagai Int
    @field:SerializedName("beginTime") val beginTime: String = "",
    @field:SerializedName("endTime") val endTime: String = "",
    @field:SerializedName("category") val category: String = "",
    var isFavorite: Boolean = false
) : Parcelable {

    // Fungsi konversi ListEventsItem ke Event
    fun toEvent(): Event {
        return Event(
            id = id.toString(),  // Pastikan konsistensi ke String di model Event
            name = name,
            description = description,
            date = beginTime,
            imageUrl = mediaCover,
            isFavorite = isFavorite
        )
    }

    val isActive: Boolean
        get() = try {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val endDate: Date = dateFormat.parse(endTime) ?: Date(0)
            endDate.after(Date())
        } catch (e: ParseException) {
            false
        }

    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readString() ?: "",
        parcel.readInt(),  // Konsisten sebagai Int
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readByte() != 0.toByte()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(summary)
        parcel.writeString(mediaCover)
        parcel.writeInt(registrants)
        parcel.writeString(imageLogo)
        parcel.writeString(link)
        parcel.writeString(description)
        parcel.writeString(ownerName)
        parcel.writeString(cityName)
        parcel.writeInt(quota)
        parcel.writeString(name)
        parcel.writeInt(id)  // Konsisten sebagai Int
        parcel.writeString(beginTime)
        parcel.writeString(endTime)
        parcel.writeString(category)
        parcel.writeByte(if (isFavorite) 1 else 0)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<ListEventsItem> {
        override fun createFromParcel(parcel: Parcel): ListEventsItem {
            return ListEventsItem(parcel)
        }

        override fun newArray(size: Int): Array<ListEventsItem?> {
            return arrayOfNulls(size)
        }
    }
}
