package com.dev.eventdicoding.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.dev.eventdicoding.database.EventFavoriteEntity
import com.dev.eventdicoding.repository.EventRepository
import kotlinx.coroutines.launch

class FavoriteViewModel(private val repository: EventRepository) : ViewModel() {

    val allFavorites = repository.getAllFavorites().asLiveData() // Pastikan asLiveData diimpor

    fun addFavorite(event: EventFavoriteEntity) {
        viewModelScope.launch {
            repository.addFavorite(event)
        }
    }

    fun removeFavorite(event: EventFavoriteEntity) {
        viewModelScope.launch {
            repository.removeFavorite(event)
        }
    }
}
