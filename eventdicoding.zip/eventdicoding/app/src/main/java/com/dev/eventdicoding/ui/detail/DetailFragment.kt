package com.example.eventdicoding.ui.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.text.HtmlCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.dev.eventdicoding.viewmodel.FavoriteViewModel
import com.example.eventdicoding.R
import com.example.eventdicoding.data.response.ListEventsItem
import com.example.eventdicoding.databinding.FragmentDetailBinding
import com.example.eventdicoding.database.toEntity
import com.example.eventdicoding.database.toEvent
import org.koin.androidx.viewmodel.ext.android.viewModel
import android.widget.Toast

class DetailFragment : Fragment() {

    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!

    // Inject ViewModel using Koin
    private val favoriteViewModel: FavoriteViewModel by viewModel()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Handle toolbar navigation click
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        // Retrieve the selected event from arguments
        val selectedEvent = arguments?.getParcelable<ListEventsItem>("selectedEvent")

        if (selectedEvent != null) {
            displayEventDetails(selectedEvent)
        } else {
            Toast.makeText(requireContext(), "Event data not found", Toast.LENGTH_SHORT).show()
            findNavController().navigateUp()
        }
    }

    // Display event details in the UI
    private fun displayEventDetails(listEventItem: ListEventsItem) {
        val event = listEventItem.toEvent()

        binding.apply {
            tvEventName.text = event.name
            tvEventDate.text = event.date
            tvEventLocation.text = listEventItem.cityName
            tvOrganizerName.text = listEventItem.ownerName
            tvQuota.text = "${listEventItem.quota - listEventItem.registrants} sisa kuota"
            tvEventDescription.text = HtmlCompat.fromHtml(
                listEventItem.description ?: "No description available",
                HtmlCompat.FROM_HTML_MODE_LEGACY
            )

            // Load event image using Glide
            Glide.with(this@DetailFragment)
                .load(listEventItem.mediaCover)
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.error_image)
                .into(ivEventImage)

            // Set favorite icon based on the current state
            updateFavoriteIcon(event.isFavorite)

            // Handle favorite icon click
            ivFavorite.setOnClickListener {
                toggleFavorite(event)
            }
        }
    }

    // Toggle the favorite state of the event
    private fun toggleFavorite(event: com.example.eventdicoding.model.Event) {
        if (event.isFavorite) {
            favoriteViewModel.removeFavorite(event.toEntity())
            showToast("Removed from favorites")
        } else {
            favoriteViewModel.addFavorite(event.toEntity())
            showToast("Added to favorites")
        }
        event.isFavorite = !event.isFavorite
        updateFavoriteIcon(event.isFavorite)
    }

    // Update the favorite icon based on the state
    private fun updateFavoriteIcon(isFavorite: Boolean) {
        binding.ivFavorite.setImageResource(
            if (isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border
        )
    }

    // Display a toast message
    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
