package com.dev.eventdicoding.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {

    // Insert or update event
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: EventFavoriteEntity)

    // Delete event by entity
    @Delete
    suspend fun delete(event: EventFavoriteEntity): Int // Return jumlah baris terhapus

    // Delete event by ID
    @Query("DELETE FROM event_favorites WHERE id = :id")
    suspend fun deleteById(id: Int): Int // ID konsisten sebagai Int

    // Get favorite event by ID (nullable)
    @Query("SELECT * FROM event_favorites WHERE id = :id LIMIT 1")
    suspend fun getFavoriteById(id: Int): EventFavoriteEntity?

    // Check if an event is marked as favorite (returns true/false)
    @Query("SELECT EXISTS(SELECT 1 FROM event_favorites WHERE id = :id)")
    suspend fun isFavorite(id: Int): Boolean

    // Get all favorite events ordered by date
    @Query("SELECT * FROM event_favorites ORDER BY date DESC")
    fun getAllFavorites(): Flow<List<EventFavoriteEntity>>
}
