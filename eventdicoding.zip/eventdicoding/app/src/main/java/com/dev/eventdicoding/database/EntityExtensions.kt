package com.example.eventdicoding.database

import com.dev.eventdicoding.database.EventFavoriteEntity
import com.example.eventdicoding.data.response.ListEventsItem
import com.example.eventdicoding.model.Event

// Konversi dari ListEventsItem ke Event
fun ListEventsItem.toEvent(): Event {
    return Event(
        id = this.id.toString(), // Konversi ID menjadi String untuk konsistensi
        name = this.name,
        description = this.description,
        date = this.beginTime,
        imageUrl = this.mediaCover,
        isFavorite = false // Default value
    )
}


// Konversi dari Event ke EventFavoriteEntity
fun Event.toEntity(): EventFavoriteEntity {
    return EventFavoriteEntity(
        id = this.id.toInt(),
        name = this.name,
        description = this.description,
        date = this.date,
        imageUrl = this.imageUrl,
        isFavorite = this.isFavorite
    )
}
