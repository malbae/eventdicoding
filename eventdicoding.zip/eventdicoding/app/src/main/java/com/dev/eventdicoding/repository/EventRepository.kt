package com.dev.eventdicoding.repository

import com.dev.eventdicoding.database.EventFavoriteEntity
import com.dev.eventdicoding.database.FavoriteDao

class EventRepository(private val favoriteDao: FavoriteDao) {

    fun getAllFavorites() = favoriteDao.getAllFavorites()

    suspend fun addFavorite(event: EventFavoriteEntity) {
        favoriteDao.insert(event)
    }

    suspend fun removeFavorite(event: EventFavoriteEntity) {
        favoriteDao.delete(event)
    }
}
